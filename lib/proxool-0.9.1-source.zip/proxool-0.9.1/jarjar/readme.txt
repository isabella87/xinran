Cglib 2.1_3 has been patched so that it can be correctly processed by JarJar. See
cglib-nodep-2.1_3-patch-BH1.patch for details.  