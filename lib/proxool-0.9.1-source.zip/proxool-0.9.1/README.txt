About Proxool
------------

$Revision: 1.4 $
$Date: 2002/11/19 12:14:58 $
$Author: billhorsman $

A Java SQL Driver that provides a connection pool wrapper around another
Driver of your choice. Very simple to migrate existing code. Fully
configurable. Fast, mature and robust. Transparently adds connection
pooling to your existing JDBC driver.

You can take a look at BUILD.txt, CHANGES.txt and LICENCE.txt but you might
have better luck looking at the documentation at doc/index.html.

I would welcome any comments you would like to make on Proxool. Good or
bad.

Bill Horsman
19 September 2002
billhorsman@users.sourceforge.net
